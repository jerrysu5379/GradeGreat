import sqlite3
from hashlib import sha256
import tkinter as tk
from tkinter import messagebox
import pandas as pd
import plotly.express as px
import webbrowser
import openai
import os
from utilities.dataengineer import SQL_Data_Preparer
from utilities.datascientist import Data_Analyzer

def create_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY, password TEXT)''')
    conn.commit()
    conn.close()

def register_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    hashed_password = sha256(password.encode()).hexdigest()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError:
        return False
    conn.close()
    return True

def authenticate_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    hashed_password = sha256(password.encode()).hexdigest()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed_password))
    result = c.fetchone()
    conn.close()
    return result

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Login/Register")

        self.login_frame = tk.Frame(self.root)
        self.register_frame = tk.Frame(self.root)

        self.username_label = tk.Label(self.login_frame, text="Username")
        self.username_entry = tk.Entry(self.login_frame)
        self.password_label = tk.Label(self.login_frame, text="Password")
        self.password_entry = tk.Entry(self.login_frame, show="*")

        self.login_button = tk.Button(self.login_frame, text="Login", command=self.login)
        self.register_button = tk.Button(self.login_frame, text="Register", command=self.show_register)

        self.username_label.grid(row=0, column=0)
        self.username_entry.grid(row=0, column=1)
        self.password_label.grid(row=1, column=0)
        self.password_entry.grid(row=1, column=1)
        self.login_button.grid(row=2, column=0, columnspan=2)
        self.register_button.grid(row=3, column=0, columnspan=2)

        self.login_frame.pack()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if authenticate_user(username, password):
            messagebox.showinfo("Login Success", "Welcome, " + username + "!")
            self.show_main_app()
        else:
            messagebox.showerror("Login Failed", "Invalid credentials")

    def show_register(self):
        self.login_frame.pack_forget()
        self.register_frame.pack()

        self.reg_username_label = tk.Label(self.register_frame, text="Username")
        self.reg_username_entry = tk.Entry(self.register_frame)
        self.reg_password_label = tk.Label(self.register_frame, text="Password")
        self.reg_password_entry = tk.Entry(self.register_frame, show="*")

        self.reg_button = tk.Button(self.register_frame, text="Register", command=self.register)
        self.back_button = tk.Button(self.register_frame, text="Back", command=self.show_login)

        self.reg_username_label.grid(row=0, column=0)
        self.reg_username_entry.grid(row=0, column=1)
        self.reg_password_label.grid(row=1, column=0)
        self.reg_password_entry.grid(row=1, column=1)
        self.reg_button.grid(row=2, column=0, columnspan=2)
        self.back_button.grid(row=3, column=0, columnspan=2)

    def register(self):
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()
        if register_user(username, password):
            messagebox.showinfo("Registration Success", "User registered successfully!")
            self.show_login()
        else:
            messagebox.showerror("Registration Failed", "Username already exists")

    def show_login(self):
        self.register_frame.pack_forget()
        self.login_frame.pack()

    def show_main_app(self):
        self.login_frame.pack_forget()
        MainApp(self.root)

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Main Application")

        self.frame = tk.Frame(self.root)
        self.frame.pack()

        self.question_label = tk.Label(self.frame, text="Ask me a question")
        self.question_label.pack()

        self.question_entry = tk.Entry(self.frame, width=50)
        self.question_entry.pack()

        self.submit_button = tk.Button(self.frame, text="Submit", command=self.submit)
        self.submit_button.pack()

        self.plot_button = tk.Button(self.frame, text="Show Plot", command=self.show_plot)
        self.plot_button.pack()

        self.result_label = tk.Label(self.frame, text="")
        self.result_label.pack()

        self.api_key = os.getenv("AZURE_OPENAI_API_KEY")
        self.api_base = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.gpt_deployment = os.getenv("AZURE_OPENAI_CHATGPT_DEPLOYMENT", "gpt-35-turbo")

        self.sql_engine = os.getenv("SQL_ENGINE", "sqlite")
        self.db_path = os.getenv("SQLITE_DB_PATH", "data/northwind.db")

    def submit(self):
        question = self.question_entry.get()
        response = self.ask_openai(question)
        self.result_label.config(text=response)

    def ask_openai(self, question):
        openai.api_key = self.api_key
        openai.api_base = self.api_base

        data_preparer = SQL_Data_Preparer(sql_engine=self.sql_engine, st=self, db_path=self.db_path, gpt_deployment=self.gpt_deployment, max_response_tokens=1250, token_limit=4096, temperature=0)
        analyzer = Data_Analyzer(st=self, gpt_deployment=self.gpt_deployment, max_response_tokens=1250, token_limit=4096, temperature=0)

        if "prepare" in question.lower():
            data_preparer.run(question, show_code=True, show_prompt=True, st=self)
        else:
            analyzer.run(question, data_preparer, show_code=True, show_prompt=True, st=self)

    def show_plot(self):
        df = pd.DataFrame({
            "x": [1, 2, 3, 4],
            "y": [10, 11, 12, 13]
        })

        fig = px.line(df, x="x", y="y", title="Simple Plot")
        fig.show()
        fig.write_html("figure.html")
        webbrowser.open("figure.html")

if __name__ == "__main__":
    create_db()
    root = tk.Tk()
    app = App(root)
    root.mainloop()